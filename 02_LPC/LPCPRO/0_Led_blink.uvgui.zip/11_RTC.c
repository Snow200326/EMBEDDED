/*#include <LPC214X.H>
#define rs (1<<8)
#define E (1<<9)

void delay(int a);
void cmd(char cm);
void data(char dt);
void string( char* str);
void set_time();
void time();
void PLL_INIT();


int main()
{
	PLL_INIT();

	IODIR0=0xfff;
cmd(0x38);  // Function Set: 8-bit, 2 line, 5x7 dots
cmd(0x0C);  // Display ON, Cursor OFF
cmd(0x06);  // Entry Mode Set
cmd(0x01);  // Clear Display
delay(200); // Add delay after clear display
cmd(0x80);  // Set cursor to first line
	
	cmd(0x80);
	string("HH:MM:SS ");
	set_time();
	while(1)
{
	time();

}
}

void cmd(char cm)
{
	
	IOSET0=cm;
	IOCLR0=rs;
	IOSET0=E;
	delay(100);
	IOCLR0=E;
	IOCLR0=cm;

}
void data(char dt)
{
	IOSET0=dt;
	IOSET0=rs;
	IOSET0=E;
	delay(100);
		IOCLR0=E;
		IOCLR0=rs;
		IOCLR0=dt;

}
void string( char* str)
{
    int i = 0;
    while (*str)  // Loop through the string until the null-terminator
        data(*str++);  // Send each character to the LCD
        //str++;
    
}
void delay(int a)
{
	int i,j;
	for(i=0;i<a;i++)
	{
		for(j=0;j<i;j++);
	}
}
void PLL_INIT()
{
	PLL0CON=0X01;
	PLL0CFG=0X24;
	PLL0FEED=0XAA;
		PLL0FEED=0X55;
	 while ((PLL0STAT & (1 << 10)) == 0); 
	PLL0FEED=0XAA;
		PLL0FEED=0X55;
	VPBDIV=0X00;///15 MHZ
}
void set_time()
{
	PREINT=456;
	PREFRAC=25024;
	CCR=0X12;//reset clock /// RTC oscillator /// 
	HOUR=23;
	MIN=59;
	SEC=56;
	
	
	
		CCR=0X11;//enable enable the clock
}
void time()
{
	cmd(0xc1);///second line
	data('0'+(HOUR/10));
	data('0'+(HOUR%10));
	data(':');
	data('0'+(MIN/10)); ///45/10=4
	data('0'+(MIN%10));  ////45%10=5
	data(':');
	data('0'+(SEC/10));
	data('0'+(SEC%10));
	data(':');
}
*/


#include <LPC214X.H>

#define rs (1<<8)
#define E  (1<<9)

void delay(int a);
void cmd(char cm);
void data(char dt);
void string(char* str);
void set_time_date();
void display_time_date();
void PLL_INIT();

int main()
{
    PLL_INIT();

    IODIR0 = 0xFFF;

    cmd(0x38);  
    cmd(0x0C);  
    cmd(0x06);  
    cmd(0x01);  
    delay(200);
    
    set_time_date();

    while(1)
    {
        display_time_date();
    }
}

// LCD COMMAND
void cmd(char cm)
{
    IOSET0 = cm;
    IOCLR0 = rs;
    IOSET0 = E;
    delay(100);
    IOCLR0 = E;
    IOCLR0 = cm;
}

// LCD DATA
void data(char dt)
{
    IOSET0 = dt;
    IOSET0 = rs;
    IOSET0 = E;
    delay(100);
    IOCLR0 = E;
    IOCLR0 = rs;
    IOCLR0 = dt;
}

// STRING PRINT
void string(char* str)
{
    while(*str)
        data(*str++);
}

// DELAY
void delay(int a)
{
    int i,j;
    for(i=0;i<a;i++)
        for(j=0;j<600;j++);
}

// PLL INIT
void PLL_INIT()
{
    PLL0CON = 0x01;
    PLL0CFG = 0x24;
    PLL0FEED = 0xAA;
    PLL0FEED = 0x55;

    while((PLL0STAT & (1<<10)) == 0);

    PLL0FEED = 0xAA;
    PLL0FEED = 0x55;

    VPBDIV = 0x00;   // 15 MHz PCLK
}
// SET TIME & DATE
void set_time_date()
{
    PREINT  = 456;
    PREFRAC = 25024;

    CCR = 0x12;   // Reset RTC & enable oscillator

    // TIME
    HOUR = 23;
    MIN  = 59;
    SEC  = 50;

    // DATE
    DOM  = 2;     // Day: 04
    MONTH = 2;   // Month: Dec
    YEAR = 26;    // Year: 2025 (only last 2 digits)

    CCR = 0x11;   // Enable RTC
}

// DISPLAY DATE & TIME
void display_time_date()
{
    // ------- LINE 1 ? DATE (DD-MM-YY) -------
    cmd(0x80);

    data('0' + (DOM / 10));  ////12/10==1 12%10==2
    data('0' + (DOM % 10));
    data('-');

    data('0' + (MONTH / 10));
    data('0' + (MONTH % 10));
    data('-');

    data('0' + (YEAR / 10));
    data('0' + (YEAR % 10));


    // ------- LINE 2 ? TIME (HH:MM:SS) -------
    cmd(0xC0);

    data('0' + (HOUR / 10));
    data('0' + (HOUR % 10));
    data(':');

    data('0' + (MIN / 10));
    data('0' + (MIN % 10));
    data(':');

    data('0' + (SEC / 10));
    data('0' + (SEC % 10));
}


/*#include <LPC214X.H>
#define rs (1<<8)
#define E (1<<9)

void delay(int a);
void cmd(char cm);
void data(char dt);
void string( char* str);
void set_time();
void time();
void PLL_INIT();


int main()
{
	PLL_INIT();

	IODIR0=0xfff;
cmd(0x38);  // Function Set: 8-bit, 2 line, 5x7 dots
cmd(0x0C);  // Display ON, Cursor OFF
cmd(0x06);  // Entry Mode Set
cmd(0x01);  // Clear Display
delay(200); // Add delay after clear display
cmd(0x80);  // Set cursor to first line
	
	cmd(0x80);
	string("HH:MM:SS ");
	set_time();
	while(1)
{
	time();

}
}

void cmd(char cm)
{
	
	IOSET0=cm;
	IOCLR0=rs;
	IOSET0=E;
	delay(100);
	IOCLR0=E;
	IOCLR0=cm;

}
void data(char dt)
{
	IOSET0=dt;
	IOSET0=rs;
	IOSET0=E;
	delay(100);
		IOCLR0=E;
		IOCLR0=rs;
		IOCLR0=dt;

}
void string( char* str)
{
    int i = 0;
    while (*str)  // Loop through the string until the null-terminator
        data(*str++);  // Send each character to the LCD
        //str++;
    
}
void delay(int a)
{
	int i,j;
	for(i=0;i<a;i++)
	{
		for(j=0;j<i;j++);
	}
}
void PLL_INIT()
{
	PLL0CON=0X01;
	PLL0CFG=0X24;
	PLL0FEED=0XAA;
		PLL0FEED=0X55;
	 while ((PLL0STAT & (1 << 10)) == 0); 
	PLL0FEED=0XAA;
		PLL0FEED=0X55;
	VPBDIV=0X00;///15 MHZ
}
void set_time()
{
	PREINT=456;
	PREFRAC=25024;
	CCR=0X12;//reset clock /// RTC oscillator /// 
	HOUR=23;
	MIN=59;
	SEC=56;
	
	
	
		CCR=0X11;//enable enable the clock
}
void time()
{
	cmd(0xc1);///second line
	data('0'+(HOUR/10));
	data('0'+(HOUR%10));
	data(':');
	data('0'+(MIN/10)); ///45/10=4
	data('0'+(MIN%10));  ////45%10=5
	data(':');
	data('0'+(SEC/10));
	data('0'+(SEC%10));
	data(':');
}
*/


//#include <LPC214X.H>

//#define rs (1<<8)
//#define E  (1<<9)

//void delay(int a);
//void cmd(char cm);
//void data(char dt);
//void string(char* str);
//void set_time_date();
//void display_time_date();
//void PLL_INIT();

//int main()
//{
//    PLL_INIT();

//    IODIR0 = 0xFFF;

//    cmd(0x38);  
//    cmd(0x0C);  
//    cmd(0x06);  
//    cmd(0x01);  
//    delay(200);
//    
//    set_time_date();

//    while(1)
//    {
//        display_time_date();
//    }
//}

//// LCD COMMAND
//void cmd(char cm)
//{
//    IOSET0 = cm;
//    IOCLR0 = rs;
//    IOSET0 = E;
//    delay(100);
//    IOCLR0 = E;
//    IOCLR0 = cm;
//}

//// LCD DATA
//void data(char dt)
//{
//    IOSET0 = dt;
//    IOSET0 = rs;
//    IOSET0 = E;
//    delay(100);
//    IOCLR0 = E;
//    IOCLR0 = rs;
//    IOCLR0 = dt;
//}

//// STRING PRINT
//void string(char* str)
//{
//    while(*str)
//        data(*str++);
//}

//// DELAY
//void delay(int a)
//{
//    int i,j;
//    for(i=0;i<a;i++)
//        for(j=0;j<600;j++);
//}

//// PLL INIT
//void PLL_INIT()
//{
//    PLL0CON = 0x01;
//    PLL0CFG = 0x24;
//    PLL0FEED = 0xAA;
//    PLL0FEED = 0x55;

//    while((PLL0STAT & (1<<10)) == 0);

//    PLL0FEED = 0xAA;
//    PLL0FEED = 0x55;

//    VPBDIV = 0x00;   // 15 MHz PCLK
//}
//// SET TIME & DATE
//void set_time_date()
//{
//    PREINT  = 456;
//    PREFRAC = 25024;

//    CCR = 0x12;   // Reset RTC & enable oscillator

//    // TIME
//    HOUR = 23;
//    MIN  = 59;
//    SEC  = 50;

//    // DATE
//    DOM  = 2;     // Day: 04
//    MONTH = 2;   // Month: Dec
//    YEAR = 26;    // Year: 2025 (only last 2 digits)

//    CCR = 0x11;   // Enable RTC
//}

//// DISPLAY DATE & TIME
//void display_time_date()
//{
//    // ------- LINE 1 ? DATE (DD-MM-YY) -------
//    cmd(0x80);

//    data('0' + (DOM / 10));  ////12/10==1 12%10==2
//    data('0' + (DOM % 10));
//    data('-');

//    data('0' + (MONTH / 10));
//    data('0' + (MONTH % 10));
//    data('-');

//    data('0' + (YEAR / 10));
//    data('0' + (YEAR % 10));


//    // ------- LINE 2 ? TIME (HH:MM:SS) -------
//    cmd(0xC0);

//    data('0' + (HOUR / 10));
//    data('0' + (HOUR % 10));
//    data(':');

//    data('0' + (MIN / 10));
//    data('0' + (MIN % 10));
//    data(':');

//    data('0' + (SEC / 10));
//    data('0' + (SEC % 10));
//}

////#include <LPC214X.H>
////#define LED (1<<10)
////#define rs (1<<8)
////#define E  (1<<9)

////void delay(int a);
////void cmd(char cm);
////void data(char dt);
////void string(char* str);
////void set_time_date();
////void display_time_date();
////void PLL_INIT();

////int main()
////{   IODIR0 |= LED; 
////    PLL_INIT();

////    IODIR0 = 0xFFF;

////    cmd(0x38);  
////    cmd(0x0C);  
////    cmd(0x06);  
////    cmd(0x01);  
////	   cmd(0x80);  
////	
////    delay(200);
////    
////    set_time_date();

////    while(1)
//    {
//        display_time_date();
//    }
//}

//// LCD COMMAND
//void cmd(char cm)
//{
//    IOSET0 = cm;
//    IOCLR0 = rs;
//    IOSET0 = E;
//    delay(100);
//    IOCLR0 = E;
//    IOCLR0 = cm;
//}

//// LCD DATA
//void data(char dt)
//{
//    IOSET0 = dt;
//    IOSET0 = rs;
//    IOSET0 = E;
//    delay(100);
//    IOCLR0 = E;
//    IOCLR0 = rs;
//    IOCLR0 = dt;
//}

//// STRING PRINT
//void string(char* str)
//{
//    while(*str)
//        data(*str++);
//}

//// DELAY
//void delay(int a)
//{
//    int i,j;
//    for(i=0;i<a;i++)
//        for(j=0;j<600;j++);
//}

//// PLL INIT
//void PLL_INIT()
//{
//    PLL0CON = 0x01;
//    PLL0CFG = 0x24;
//    PLL0FEED = 0xAA;
//    PLL0FEED = 0x55;

//    while((PLL0STAT & (1<<10)) == 0);

//    PLL0FEED = 0xAA;
//    PLL0FEED = 0x55;

//    VPBDIV = 0x00;   // 15 MHz PCLK
//}
//// SET TIME & DATE
//void set_time_date()
//{
//    PREINT  = 456;
//    PREFRAC = 25024;

//    CCR = 0x12;   // Reset RTC & enable oscillator

//    // TIME
//    HOUR = 23;
//    MIN  = 59;
//    SEC  = 50;

//    // DATE
//    DOM  = 2;     // Day: 04
//    MONTH = 2;   // Month: Dec
//    YEAR = 26;    // Year: 2025 (only last 2 digits)

//    CCR = 0x11;   // Enable RTC
//}

//// DISPLAY DATE & TIME
//void display_time_date()
//{
//    // ------- LINE 1 : DATE -------
//    cmd(0x85);

//    data('0' + (DOM / 10));
//    data('0' + (DOM % 10));
//    data('-');

//    data('0' + (MONTH / 10));
//    data('0' + (MONTH % 10));
//    data('-');

//    data('0' + (YEAR / 10));
//    data('0' + (YEAR % 10));

//    // ------- LINE 2 : TIME -------
//    
//	cmd(0xc0);

//    data('0' + (HOUR / 10));
//    data('0' + (HOUR % 10));
//    data(':');

//    data('0' + (MIN / 10));
//    data('0' + (MIN % 10));
//    data(':');

//    data('0' + (SEC / 10));
//    data('0' + (SEC % 10));

//    // ------- LED CONTROL -------
//    
//		
//		
//		
//if(HOUR == 23 && MIN == 59 && SEC >= 55 && SEC <= 58)
//    {
//        IOSET0 = LED;   // LED ON
//    }
//    else
//    {
//        IOCLR0 = LED;   // LED OFF
//    }
//}