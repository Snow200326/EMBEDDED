#include <LPC214x.h>
#define led 1<<4
#define sw 1<<5
void delay();
// ---------- Function to configure PLL ----------
void PLL_Init()
{
    PLL0CON = 0x01;           // Enable PLL
    PLL0CFG = 0x24;           // M=5 (M+1=6), P=2 => CCLK = 60 MHz
    PLL0FEED = 0xAA;
    PLL0FEED = 0x55;

    while ((PLL0STAT & (1 << 10)) == 0);  // Wait for PLL lock

    PLL0CON = 0x03;           // Connect PLL
    PLL0FEED = 0xAA;
    PLL0FEED = 0x55;

    VPBDIV = 0x00;            // Set PCLK = CCLK / 4 = 15 MHz
}

// ---------- Function to initialize UART0 ----------
void UART0_Init()
{
    PINSEL0 = 0x00000005;     // Enable TXD0 (P0.0) and RXD0 (P0.1)

    U0LCR = 0x83;             // 8-bit word length, 1 stop bit, no parity, DLAB=1
    U0DLL = 97;               // 9600 baud rate @ 15MHz PCLK ? 15000000 / (16 * 97)
    U0DLM = 0x00;
    U0LCR = 0x03;             // DLAB=0, lock baud rate, 8N1
}
// ---------- Function to send a single character ----------
void UART0_SendChar(char c)
{
    while (!(U0LSR & (1 << 5))); // Wait until THR is empty
    U0THR = c;                    // Send character
}

// ---------- Function to send a string ----------
void UART0_SendString(const char *str)
{
    while (*str)
    {
        UART0_SendChar(*str++);
    }
}

// ---------- Main Function ----------
int main()
{
	IODIR0 |= led;
	IODIR0 &= ~(sw);
    PLL_Init();            // Configure system clock
    UART0_Init();          // Initialize UART0

	while (1) {
		
	
				
    UART0_SendString("techno\r\n");  // Send string over UART
		delay();
		
	 UART0_SendString("scripts\r\n"); 
			delay();
		
		 UART0_SendString("embedded\r\n"); 
			delay();
		
		 UART0_SendString("pune\r\n"); 
			delay();
	
	
	

			delay();
	}
              // Loop forever
}

void delay()
{
	int i,j;
	for(i=0;i<1000;i++){
	for(j=0;j<i;j++)
		
	{
	}
}
}