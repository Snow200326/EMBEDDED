 	#include <LPC214X.H>
 	#define S1 (1<<24)
 	#define S2 (1<<25)
 	void delay(int x){
 		int i,j;
 		for(i=0;i<x;i++){
 		for(j=0;j<x;j++){
 		}
 		}
 	}
 	int main(){
 		int i;
 		int temp;
 	int arr[10] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};

 			IODIR1 = (0X3Ff<<16);
		while(1){
		for(i=0;i<100;i++){
 			 	IOCLR1= S2;
 				IOSET1 = S1;
 				temp = i/10;
 				IOSET1 = (arr[temp]<<16);
 				delay(100);
 		   	IOCLR1= (arr[temp]<<16);
 				
 				//
			  IOCLR1 = S1;
 				IOSET1 = S2;
 				temp=i%10;
 			  IOSET1 = (arr[temp]<<16);
 				delay(100);
 				IOCLR1 = (arr[temp]<<16);

 			}
	}
 	}
