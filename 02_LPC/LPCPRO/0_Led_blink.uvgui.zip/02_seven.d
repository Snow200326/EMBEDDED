.\02_seven.o: 02_seven.c
.\02_seven.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.h
