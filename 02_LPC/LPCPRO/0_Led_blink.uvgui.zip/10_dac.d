.\10_dac.o: 10_DAC.c
.\10_dac.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
