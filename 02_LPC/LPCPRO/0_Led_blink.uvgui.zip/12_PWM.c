#include <LPC214X.H>
#define led (1<<0)

void pwmInit(){
	PINSEL0=0X8002;
	PWMPCR=0X600;
	PWMTCR=0X02;
	PWMMR0=150000;
	PWMTCR=0X09;
	PWMMCR=0X02;
}

int main(){
	IODIR0=led;
	pwmInit();
	while(1){
	PWMMR1=75000;
		IOSET0 &=led;
		PWMMR2=37000;
		PWMLER=0X06;
	}
}
