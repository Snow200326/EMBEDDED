 	#include <LPC214X.H>
 	#define S1 (1<<24)
 	#define S2 (1<<25)
 	void delay(int x){
 		int i,j;
 		for(i=0;i<x;i++){
 		for(j=0;j<x;j++){
 		}
 		}
 	}
 	int main(){
 		int i;
 		int temp;
 	int arr[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
 			IODIR1 = (0X3Ff<<16);
		while(1){
		for(i=0;i<100;i++){
 			  IOCLR1 = S1;
 				IOSET1 = S2;
 				temp = i/10;
 				IOSET1 = (arr[temp]<<16);
 				delay(200);
 		   	IOCLR1= (arr[temp]<<16);
 				
 				//
 				IOCLR1= S2;
 				IOSET1 = S1;
 				temp=i%10;
 			  IOSET1 = (arr[temp]<<16);
 				delay(200);
 				IOCLR1 = (arr[temp]<<16);

 			}
	}
 	}
