
#include<LPC214X.h>
void delay(int x){
	int j,i;
	for( i=0;i<x;i++){
	for( j = 0 ;j<i;j++){};
	}
}
int main(){
		int i;

	 int  arr[16] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};

	 	IODIR0 |= 0x7f;
	 while(1){
	  for ( i = 0 ;i<16;i++)
		{
		IOSET0 = arr[i];
		delay(500);
		IOCLR0 = arr[i];
	}
}
}
