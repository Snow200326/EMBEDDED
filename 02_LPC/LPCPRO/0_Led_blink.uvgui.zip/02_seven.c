#include<LPC214X.h>
void delay(int x){
	int j,i;
	for( i=0;i<x;i++){
	for( j = 0 ;j<i;j++){};
	}
}
int main(){
		int i;

	 int arr[10] = {0x3F, 0x06, 0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
	 	IODIR0 |= 0x7f;
	 while(1){
	  for ( i = 0 ;i<10;i++)
		{
		IOSET0 = arr[i];
		delay(500);
		IOCLR0 = arr[i];
	}
}
}
