.\13_led_uart.o: 13_LED_UART.c
.\13_led_uart.o: C:\Keil_v5\ARM\Inc\Philips\LPC214x.h
