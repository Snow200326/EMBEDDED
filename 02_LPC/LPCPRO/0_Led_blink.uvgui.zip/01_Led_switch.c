#include<LPC214X.h>
int main(){

IODIR0|= (1<<1); // DIRECTIONN 1 = INPUT , 0 = OUTPUT.
IODIR0 &=~(1<<0);
while(1){
	
	if(IOPIN0 & (1<<0 ==1 )){
		IOSET0 |=(1<<1);
	}
	else{
		IOCLR0 |=(1<<1);
	}
}
}