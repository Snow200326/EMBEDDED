.\02_seven_(ca).o: 02_SEVEN_(ca).c
.\02_seven_(ca).o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.h
