.\05_motorswitch.o: 05_motorswitch.c
.\05_motorswitch.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
