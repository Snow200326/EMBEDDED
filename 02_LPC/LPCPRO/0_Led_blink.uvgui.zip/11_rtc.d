.\11_rtc.o: 11_RTC.c
.\11_rtc.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
