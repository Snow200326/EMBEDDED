.\03_2seven.o: 03_2seven.c
.\03_2seven.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
