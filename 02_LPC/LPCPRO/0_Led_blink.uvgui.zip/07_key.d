.\07_key.o: 07_KEY.c
.\07_key.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
