.\01_led_switch.o: 01_Led_switch.c
.\01_led_switch.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.h
