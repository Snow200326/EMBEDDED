#include <LPC214x.h>
#define led 1<<4
#define sw 1<<5
void delay();
// ---------- Function to configure PLL ----------
void PLL_Init()
{
    PLL0CON = 0x01;           // Enable PLL
    PLL0CFG = 0x24;           // M=5 (M+1=6), P=2 => CCLK = 60 MHz
    PLL0FEED = 0xAA;
    PLL0FEED = 0x55;

    while ((PLL0STAT & (1 << 10)) == 0);  // Wait for PLL lock

    PLL0CON = 0x03;           // Connect PLL
    PLL0FEED = 0xAA;
    PLL0FEED = 0x55;

    VPBDIV = 0x00;            // Set PCLK = CCLK / 4 = 15 MHz
}

// ---------- Function to initialize UART0 ----------
void UART0_Init()
{
    PINSEL0 = 0x00000005;     // Enable TXD0 (P0.0) and RXD0 (P0.1)

    U0LCR = 0x83;             // 8-bit word length, 1 stop bit, no parity, DLAB=1
    U0DLL = 97;               // 9600 baud rate @ 15MHz PCLK ? 15000000 / (16 * 97)
    U0DLM = 0x00;
    U0LCR = 0x03;             // DLAB=0, lock baud rate, 8N1
}
int main()
{
	int a;
	IODIR0 |= led;
	IODIR0 &= ~(sw);
    PLL_Init();            // Configure system clock
    UART0_Init();          // Initialize UART0

	while (1) {
		
		while((U0LSR & 0X01)!=1);
		a=U0RBR;
		switch(a)
		{
			case '1':
				IOSET0 = led;
			case '2' :
				IOCLR0 = led;
			break;
		}
	}
              // Loop forever
}

void delay()
{
	int i,j;
	for(i=0;i<1000;i++){
	for(j=0;j<i;j++)
		
	{
	}
}
}