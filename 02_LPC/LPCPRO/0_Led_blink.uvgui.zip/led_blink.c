#include<LPC214X.h>
void delay(int a){
	int i;
	int j;
	for( i = 0;i<a;i++){
		for(j =0;j<a ; j++);
	}
}
int main(){
IODIR0 |=(1<<1); // led output device..... // direction is 1
	while(1){
		IOSET0 |=(1<<1); // set the led to high
		delay(500);
		IOCLR0 |=(1<<1); 
		delay(500); 
	}
}