#include <LPC214X.H>
#define IN1 (0<<0)
#define IN2 (1<<1)
#define EN1  (1<<2)
int main(){
	
	IODIR0 =(0X07);
	while(1){
		IOSET0 = EN1;
		IOSET0 = IN1;
		IOSET0 = IN2;
	}
}