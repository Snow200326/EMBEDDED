#include <LPC214X.H>
#define EN1 (1<<2)
#define IN1 (1<<0)
#define IN2 (1<<1)
#define SW1 (1<<16)


#define EN2 (1<<8)
#define IN3 (1<<9)
#define IN4 (1<<10)
#define SW2 (1<<17)

int main()
{
	IODIR0 = 0X3ff;
	IODIR1 &= ~(0x03<<16);
	
	while(1){
		if((IOPIN1 & SW1 )== 0){
			IOSET0 = EN1;
			IOCLR0 = IN1;
			IOSET0 = IN2;
		}
		else {
			IOCLR0 |= EN1;
		}
			if((IOPIN1 & SW2 )== 0){
			IOSET0 = EN2;
			IOCLR0 = IN3;
			IOSET0 = IN4;
		}
			else{
					IOCLR0 |= EN2;
			}
		
	}
}