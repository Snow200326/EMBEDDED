.\06_lcd.o: 06_LCD.c
.\06_lcd.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
