.\08_adc.o: 08_ADC.c
.\08_adc.o: C:\Keil_v5\ARM\Inc\Philips\lpc214x.h
