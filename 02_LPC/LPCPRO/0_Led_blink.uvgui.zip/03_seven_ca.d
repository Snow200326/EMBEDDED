.\03_seven_ca.o: 03_seven_ca.c
.\03_seven_ca.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
