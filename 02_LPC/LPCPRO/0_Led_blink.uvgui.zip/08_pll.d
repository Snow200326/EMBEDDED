.\08_pll.o: 08_PLL.c
.\08_pll.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
