.\12_pwm.o: 12_PWM.c
.\12_pwm.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
