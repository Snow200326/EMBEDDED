#include <LPC214X.H>


void initPLL(){
	PLL0CON = 0X01;
	PLL0CFG = 0X24;
	PLL0FEED = 0XAA ; PLL0FEED = 0X55;
	while( PLL0STAT & 0X400 == 0);
	PLL0CON = 0X03;
	PLL0CON = 0X03;
	PLL0FEED = 0XAA; PLL0FEED = 0X55;
	VPBDIV = 0X01;
	
}










