.\02_seven_ca.o: 02_seven_ca.c
.\02_seven_ca.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
