#include <LPC214X.H>
#define rs (1<<8)
#define E (1<<9)
void delay(int a);
void cmd(int cm);
void data(char dt);
void string( char* str);

int main()
{
    IODIR0=0x3f<<4;  // 11 1111

    // LCD initialization in 4-bit mode
    cmd(0x02);  // 4-bit mode
    cmd(0x28);  // 2-line, 5x8 matrix
    cmd(0x01);  // Display ON, cursor OFF
    cmd(0x0f);  // Increment cursor
    cmd(0x06);  // Clear display
    //delay(100);

   
			while(1)
				{
        cmd(0x80);           // First line
        string("techno  ");
        delay(100);  
        string("scripts ");
        delay(100);
					
					cmd(0xc0);
					string("embedded  ");
        delay(100);
                // Second line
        string("pune ");
        delay(100);
					
			cmd(0x01);
			}

}
void cmd(int cm)
{
    int temp;

    // Send higher nibble
    temp=(cm&0xF0);
             // Clear previous data
    IOSET0= temp;
    IOCLR0 = rs;             // RS = 0 for command
    IOSET0 = E;
    delay(100);
    IOCLR0 = E;
    IOCLR0= temp;
    // Send lower nibble
    temp=(cm&0x0F);
	 temp=temp<< 4;
	
    IOSET0=temp;
    IOCLR0 = rs;
    IOSET0 = E;
    delay(100);
    IOCLR0 = E;
	  IOCLR0= temp;
	
}

void data(char dt)
{
    char temp;

    // Send higher nibble
    temp=(dt&0xF0);
   
    IOSET0 = temp;
    IOSET0 = rs;             // RS = 1 for data
    IOSET0 = E;
    delay(100);
    IOCLR0 = E;
	 IOCLR0= temp;

    // Send lower nibble
    temp = (dt&0x0F);
	temp=temp<< 4;
    IOSET0 = temp;
    IOSET0 = rs;
    IOSET0 = E;
    delay(100);
    IOCLR0 = E;
	 IOCLR0= temp;
}

void string( char* str)
{
    //int i = 0;
    while(*str)  // Loop through the string until the null-terminator
     data(*str++);  // Send each character to the LCD
        //str++;
    
}
void delay(int a)
{
	int i,j;
	for(i=0;i<a;i++)
	{
		for(j=0;j<i;j++);
	}
}