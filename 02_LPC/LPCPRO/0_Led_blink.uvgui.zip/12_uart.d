.\12_uart.o: 12_UART.c
.\12_uart.o: C:\Keil_v5\ARM\Inc\Philips\LPC214x.h
