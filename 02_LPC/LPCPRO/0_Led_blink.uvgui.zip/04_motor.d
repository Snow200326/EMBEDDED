.\04_motor.o: 04_motor.c
.\04_motor.o: C:\Keil_v5\ARM\Inc\Philips\LPC214X.H
